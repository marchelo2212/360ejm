H5P.GoToScene = (function () {

  function GoToScene() {

    /**
     * Attach interaction
     */
    this.attach = function () {};
  }

  return GoToScene;
})();
